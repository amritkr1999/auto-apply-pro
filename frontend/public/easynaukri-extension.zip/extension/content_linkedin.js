// EasyNaukri LinkedIn Job Post & HR Harvester Content Script

const BACKEND_URL = 'http://localhost:8060';
const processedPosts = new Set();
const getEmailRegex = () => /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}/gi;

console.log('⚡ EasyNaukri LinkedIn Harvester Script active on:', window.location.href);

// 1. Toast Notification Helper
function showToast(message, isSuccess = true, actionUrl = null, actionText = '📋 View Harvested Vault') {
  let toast = document.getElementById('easynaukri-toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'easynaukri-toast';
    toast.style.cssText = `
      position: fixed;
      bottom: 24px;
      right: 24px;
      z-index: 999999;
      background: ${isSuccess ? '#0f172a' : '#7f1d1d'};
      color: #ffffff;
      padding: 12px 20px;
      border-radius: 14px;
      box-shadow: 0 10px 25px -5px rgba(0,0,0,0.5);
      border: 1px solid ${isSuccess ? '#10b981' : '#ef4444'};
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      font-size: 13px;
      font-weight: 600;
      display: flex;
      align-items: center;
      gap: 12px;
      transition: all 0.3s ease;
    `;
    document.body.appendChild(toast);
  }

  let htmlContent = `<span>⚡</span> <span>${message}</span>`;
  if (actionUrl) {
    htmlContent += `
      <a href="${actionUrl}" target="_blank" style="
        background: linear-gradient(135deg, #10b981 0%, #059669 100%);
        color: white;
        text-decoration: none;
        padding: 5px 12px;
        border-radius: 20px;
        font-size: 11px;
        font-weight: 700;
        margin-left: 6px;
        display: inline-flex;
        align-items: center;
        gap: 4px;
        box-shadow: 0 2px 6px rgba(16,185,129,0.4);
      ">${actionText} →</a>
    `;
  }

  toast.innerHTML = htmlContent;
  toast.style.opacity = '1';
  toast.style.transform = 'translateY(0)';

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px)';
  }, 7000);
}

let isAutoScrolling = false;
let autoScrollTimer = null;

function scrollActiveContainer(distance) {
  const scrollContainers = document.querySelectorAll(
    '.scaffold-layout__main, .search-results-container, .jobs-search-results-list, .scaffold-finite-scroll__content, main'
  );
  let scrolledContainer = false;
  scrollContainers.forEach(container => {
    if (container && container.scrollHeight > container.clientHeight) {
      container.scrollBy({ top: distance, behavior: 'smooth' });
      scrolledContainer = true;
    }
  });
  window.scrollBy({ top: distance, behavior: 'smooth' });
}

function toggleAutoScroll() {
  const btn = document.getElementById('easynaukri-autoscroll-btn');
  if (!isAutoScrolling) {
    isAutoScrolling = true;
    if (btn) {
      btn.innerHTML = '⏸ Pause Auto-Scroll';
      btn.style.background = 'linear-gradient(135deg, #ef4444 0%, #dc2626 100%)';
    }
    showToast('⚡ Auto-Scroll Harvester active! Parsing jobs on screen...', true, 'http://localhost:5173/opportunities/harvester?tab=harvested', '📋 Open Harvested Vault');
    
    autoScrollTimer = setInterval(() => {
      const scrollDistance = Math.floor(Math.random() * 250) + 200;
      scrollActiveContainer(scrollDistance);

      harvestAllVisibleJobPosts();

      // Click any "See more" / "Load more jobs" buttons automatically
      const seeMoreBtns = document.querySelectorAll('.feed-shared-inline-show-more-text__button, button.see-more-jobs, .artdeco-button--muted');
      seeMoreBtns.forEach(b => {
        if (b && b.innerText && (b.innerText.toLowerCase().includes('see more') || b.innerText.toLowerCase().includes('load more'))) {
          b.click();
        }
      });
    }, 1400);
  } else {
    isAutoScrolling = false;
    if (autoScrollTimer) clearInterval(autoScrollTimer);
    if (btn) {
      btn.innerHTML = '▶ Start Auto-Scroll';
      btn.style.background = 'linear-gradient(135deg, #10b981 0%, #059669 100%)';
    }
    showToast('Auto-Scroll Harvester paused.', true);
  }
}

// 2. Sticky Top Harvester Control Bar
function injectTopHarvesterBar() {
  if (!document.body) return;
  if (document.getElementById('easynaukri-top-bar')) return;

  const bar = document.createElement('div');
  bar.id = 'easynaukri-top-bar';
  bar.style.cssText = `
    position: fixed;
    top: 56px;
    left: 50%;
    transform: translateX(-50%);
    z-index: 999980;
    background: #0f172a;
    color: #ffffff;
    padding: 6px 16px;
    border-radius: 30px;
    box-shadow: 0 8px 25px rgba(0,0,0,0.5);
    border: 1px solid #3b82f6;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    font-size: 12px;
    font-weight: 700;
    display: flex;
    align-items: center;
    gap: 10px;
  `;
  bar.innerHTML = `
    <div style="display:flex; align-items:center; gap:6px;">
      <span style="color:#10b981;">●</span>
      <span>EasyNaukri Job Harvester</span>
    </div>
    <button id="easynaukri-autoscroll-btn" style="
      background: linear-gradient(135deg, #10b981 0%, #059669 100%);
      color: white;
      border: none;
      padding: 4px 12px;
      border-radius: 20px;
      font-weight: 700;
      font-size: 11px;
      cursor: pointer;
      box-shadow: 0 2px 6px rgba(16,185,129,0.4);
    ">▶ Start Auto-Scroll</button>
    <button id="easynaukri-scan-all-btn" style="
      background: linear-gradient(135deg, #3b82f6 0%, #1d4ed8 100%);
      color: white;
      border: none;
      padding: 4px 12px;
      border-radius: 20px;
      font-weight: 700;
      font-size: 11px;
      cursor: pointer;
      box-shadow: 0 2px 6px rgba(59,130,246,0.4);
    ">⚡ Harvest Job Posts On Screen</button>
  `;

  document.body.appendChild(bar);

  document.getElementById('easynaukri-autoscroll-btn')?.addEventListener('click', toggleAutoScroll);

  document.getElementById('easynaukri-scan-all-btn')?.addEventListener('click', () => {
    // Clear processedPosts set on manual click so all visible posts are re-evaluated and synced
    processedPosts.clear();
    const count = harvestAllVisibleJobPosts();
    const targetVaultUrl = 'http://localhost:5173/opportunities/harvester?tab=harvested';
    if (count === 0) {
      showToast(`Inspected page! View your saved job posts in Harvested Vault.`, true, targetVaultUrl, '📋 View Harvested Vault');
    }
  });
}

// 3. Email Filter Sanitizer
function isValidEmail(email) {
  if (!email) return false;
  const lower = email.toLowerCase().trim();
  if (lower.startsWith('support@') || lower.startsWith('info@') || lower.startsWith('noreply@') || lower.startsWith('careers@')) {
    return false;
  }
  return lower.length > 5 && lower.includes('@') && lower.includes('.');
}

// 4. Dynamic Author & Company Extractor
function extractAuthorDetails(postContainer, extractedEmail) {
  let name = '';
  let title = '';
  let company = '';

  if (postContainer) {
    // Author Name
    const nameEl = postContainer.querySelector(
      '.update-components-actor__name, .feed-shared-actor__name, span.update-components-actor__title span[dir="ltr"], .update-components-actor__title, a.app-aware-link span, .job-card-container__primary-description, .entity-result__title-text, .app-aware-link span[aria-hidden="true"]'
    );
    if (nameEl && nameEl.innerText) {
      name = nameEl.innerText.split('\n')[0].trim();
    }

    // Author Headline / Designation
    const descEl = postContainer.querySelector(
      '.update-components-actor__description, .feed-shared-actor__description, .update-components-actor__sub-description, .entity-result__primary-subtitle, .entity-result__summary'
    );
    if (descEl && descEl.innerText) {
      title = descEl.innerText.trim();
    }
  }

  // Check post body text for explicit "at [Company]" line e.g. "We're Hiring at Tech Rudraum Pvt. Ltd."
  const fullText = postContainer ? (postContainer.innerText || '') : '';
  const lines = fullText.split('\n').map(l => l.trim());

  for (let line of lines) {
    const l = line.toLowerCase();
    if (l.includes("hiring at ") || l.includes("hiring for ")) {
      const parts = line.split(/hiring at |hiring for /i);
      if (parts.length > 1 && parts[1].trim().length > 2) {
        let extractedComp = parts[1].replace(/#/g, '').replace(/🚀|📌|📩|🔥|⚡|📢|💼|🌟/gi, '').split('\n')[0].split('.')[0].split('|')[0].trim();
        if (extractedComp.length > 2 && extractedComp.length < 50) {
          company = extractedComp;
          break;
        }
      }
    }
  }

  // Check headline for "@Company" e.g. "Candidate Manager - L2 @TEKsystems"
  if (!company && title && title.includes('@')) {
    const parts = title.split('@');
    if (parts.length > 1 && parts[1].trim().length > 1) {
      company = parts[1].split('|')[0].split('-')[0].split('.')[0].trim();
    }
  }

  // Company Name Extraction from Headline
  if (!company && title && title.toLowerCase().includes(' at ')) {
    company = title.split(/ at /i)[1].split('.')[0].split('|')[0].split('-')[0].trim();
  } else if (!company && title && title.toLowerCase().includes(' @ ')) {
    company = title.split(/ @ /i)[1].split('.')[0].split('|')[0].trim();
  } else if (!company && extractedEmail && extractedEmail.includes('@')) {
    const domain = extractedEmail.split('@')[1].toLowerCase();
    if (domain && !domain.includes('gmail') && !domain.includes('yahoo') && !domain.includes('outlook') && !domain.includes('hotmail')) {
      company = domain.split('.')[0].toUpperCase();
    }
  }

  if (!company || company.length < 2) {
    company = 'Hiring Company';
  }

  if (!name || name.length < 2) {
    if (extractedEmail) {
      const prefix = extractedEmail.split('@')[0];
      name = prefix.replace(/[._\d]/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
    } else {
      name = 'Recruiter / Hiring Team';
    }
  }

  if (!title || title.length < 2) {
    title = 'Talent Acquisition / Hiring Team';
  }

  return { name, title, company };
}

function isExtensionValid() {
  try {
    return typeof chrome !== 'undefined' && chrome.runtime && !!chrome.runtime.id;
  } catch (e) {
    return false;
  }
}

// 5. Storage Queue Fallback (prevents Mixed Content TypeError on https page)
function queueInChromeStorage(item, postKey) {
  const targetVaultUrl = 'http://localhost:5173/opportunities/harvester?tab=harvested';
  try {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      chrome.storage.local.get(['pending_sync_queue'], (data) => {
        const queue = data.pending_sync_queue || [];
        queue.push({ item, sourcePortal: 'LinkedIn Search Harvester', postKey });
        chrome.storage.local.set({ pending_sync_queue: queue }, () => {
          if (isExtensionValid()) {
            try { chrome.runtime.sendMessage({ type: 'DRAIN_QUEUE_NOW' }); } catch(e) {}
          }
        });
      });
    }
  } catch (e) {
    console.warn('Storage queue fallback skipped:', e);
  }
  if (postKey) processedPosts.add(postKey);
  showToast(`Saved "${item.title}" (${item.company}) to Harvested Vault!`, true, targetVaultUrl, '📋 View Harvested Vault');
  window.dispatchEvent(new CustomEvent('harvester-sync-success', { detail: { added: 1 } }));
}

// 6. Send Scraped Item to Background Worker with Storage Queue Fallback
function sendPayloadToBackend(item, postKey) {
  const targetVaultUrl = 'http://localhost:5173/opportunities/harvester?tab=harvested';

  if (!isExtensionValid()) {
    queueInChromeStorage(item, postKey);
    return;
  }

  try {
    chrome.runtime.sendMessage(
      {
        type: 'SYNC_SCRAPED_PAYLOAD',
        sourcePortal: 'LinkedIn Search Harvester',
        item: item
      },
      (response) => {
        if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.lastError) {
          queueInChromeStorage(item, postKey);
        } else if (response && response.success) {
          if (postKey) processedPosts.add(postKey);
          showToast(`Saved "${item.title}" (${item.company}) to Harvested Vault!`, true, targetVaultUrl, '📋 View Harvested Vault');
          window.dispatchEvent(new CustomEvent('harvester-sync-success', { detail: { added: 1 } }));
        } else {
          queueInChromeStorage(item, postKey);
        }
      }
    );
  } catch (err) {
    queueInChromeStorage(item, postKey);
  }
}

// 7. Extract Exact Post Permalink
function extractExactPostPermalink(postContainer) {
  if (!postContainer) return window.location.href;

  const lnkdInLink = postContainer.querySelector('a[href*="lnkd.in/"], a[href*="/feed/update/urn:li:activity:"]');
  if (lnkdInLink && lnkdInLink.href) return lnkdInLink.href;

  const viewJobLink = postContainer.querySelector('a[href*="/jobs/view/"]');
  if (viewJobLink && viewJobLink.href) return viewJobLink.href;

  const timestampLink = postContainer.querySelector(
    '.update-components-actor__sub-description-link, a[data-control-name="actor_container"], .feed-shared-actor__sub-description a, a.app-aware-link[href*="activity"]'
  );
  if (timestampLink && timestampLink.href && timestampLink.href.includes('linkedin.com')) {
    return timestampLink.href;
  }

  const anyPostLink = postContainer.querySelector('a[href*="/feed/update/"], a[href*="/jobs/view/"], a[href*="linkedin.com/posts/"]');
  if (anyPostLink && anyPostLink.href) return anyPostLink.href;

  return window.location.href;
}

function extractJobTitle(fullText, postContainer) {
  const cardTitle = postContainer?.querySelector('.job-card-list__title, .jobs-unified-top-card__job-title, .jobs-details-top-card__job-title');
  if (cardTitle && cardTitle.innerText && cardTitle.innerText.trim().length > 3) {
    let t = cardTitle.innerText.split('\n')[0].replace(/#/g, '').replace(/🚀|📌|📩|🔥|⚡|📢|💼|🌟/gi, '').trim();
    if (t.length > 2 && t.length < 120) return t;
  }

  const lines = fullText.split('\n').map(l => l.trim()).filter(l => l.length > 0);
  const keywords = ['developer', 'engineer', 'architect', 'manager', 'lead', 'designer', 'analyst', 'specialist', 'consultant', 'executive', 'tester', 'administrator'];

  // High Priority: Explicit "Role:", "Position:", "Job Title:", "Hiring for" lines
  for (let line of lines) {
    const l = line.toLowerCase();
    if (l.startsWith('role:') || l.startsWith('position:') || l.startsWith('job title:') || l.startsWith('hiring for') || l.includes('hiring |') || l.includes('hiring:')) {
      let cleaned = line.replace(/^(role|position|job title|hiring for|hiring)\s*[:|]?\s*/gi, '')
                        .replace(/#/g, '')
                        .replace(/🚀|📌|📩|🔥|⚡|📢|💼|🌟|🚨|HOT OPENING/gi, '')
                        .replace(/^[|:,\-\s]+/, '')
                        .trim();

      // If line contains pipe '|', pick the exact segment containing a tech title keyword
      if (cleaned.includes('|')) {
        const segments = cleaned.split('|').map(s => s.trim());
        for (let seg of segments) {
          const segLower = seg.toLowerCase();
          if (keywords.some(k => segLower.includes(k))) {
            return seg;
          }
        }
      }

      if (cleaned.length > 2 && cleaned.length < 120) {
        return cleaned;
      }
    }
  }

  // Medium Priority: Lines containing engineering/designation keywords
  for (let line of lines) {
    const l = line.toLowerCase();
    if (!l.includes("we're hiring at") && !l.includes("hiring at") && keywords.some(k => l.includes(k))) {
      let cleaned = line.replace(/#/g, '').replace(/🚀|📌|📩|🔥|⚡|📢|💼|🌟|🚨|HOT OPENING|We are hiring|Hiring|We're hiring/gi, '')
                        .replace(/^[|:,\-\s]+/, '')
                        .trim();
      if (cleaned.startsWith(':')) cleaned = cleaned.substring(1).trim();

      // Handle pipe segments in headline
      if (cleaned.includes('|')) {
        const segments = cleaned.split('|').map(s => s.trim());
        for (let seg of segments) {
          const segLower = seg.toLowerCase();
          if (keywords.some(k => segLower.includes(k))) {
            return seg;
          }
        }
      }

      if (cleaned.length > 3 && cleaned.length < 120) {
        return cleaned;
      }
    }
  }

  // Fallback: first valid non-header line
  for (let line of lines) {
    const l = line.toLowerCase();
    if (!l.includes("we're hiring at") && !l.includes("hiring at") && line.length > 5 && line.length < 120) {
      return line.trim();
    }
  }

  return 'Software Engineer';
}

// 9. Extract Location from Post
function extractLocation(fullText, postContainer) {
  const locEl = postContainer?.querySelector('.job-card-container__metadata-item, .jobs-unified-top-card__bullet');
  if (locEl && locEl.innerText) return locEl.innerText.trim();

  const lower = fullText.toLowerCase();
  if (lower.includes('remote')) return 'Remote';
  if (lower.includes('hybrid')) return 'Hybrid';
  if (lower.includes('bengaluru') || lower.includes('bangalore')) return 'Bengaluru, India';
  if (lower.includes('mumbai')) return 'Mumbai, India';
  if (lower.includes('pune')) return 'Pune, India';
  if (lower.includes('hyderabad')) return 'Hyderabad, India';
  if (lower.includes('delhi') || lower.includes('noida') || lower.includes('gurugram') || lower.includes('gurgaon')) return 'NCR, India';

  return 'Remote / Hybrid';
}

// 10. Extract Salary from Post
function extractSalary(fullText) {
  const salaryRegex = /(?:₹|\$|€|£)\s*\d+(?:\.\d+)?\s*(?:-|to)?\s*(?:₹|\$|€|£)?\s*\d*(?:\.\d+)?\s*(?:lpa|k|lacs|lakhs|\/hr|\/yr|per annum)/gi;
  const match = fullText.match(salaryRegex);
  if (match && match.length > 0) {
    return match[0].trim();
  }
  if (fullText.toLowerCase().includes('lpa')) {
    const lpaLines = fullText.split('\n').filter(l => l.toLowerCase().includes('lpa'));
    if (lpaLines.length > 0) return lpaLines[0].substring(0, 30).trim();
  }
  return 'Not Disclosed';
}

// 11. Extract Requirements & Tech Stack
function extractRequirements(fullText) {
  const techKeywords = ['Java', 'Spring Boot', 'React', 'Node.js', 'TypeScript', 'Python', 'PostgreSQL', 'Docker', 'AWS', 'Kubernetes', 'Microservices', 'Kafka', 'SQL', 'Next.js', 'Angular', 'C++', 'Go', 'GraphQL'];
  const matched = techKeywords.filter(tech => fullText.toLowerCase().includes(tech.toLowerCase()));
  if (matched.length > 0) {
    return matched.join(', ');
  }
  return 'Java, Spring Boot, React, Microservices';
}

// 12. Parse Single Job Post Container
function parseAndHarvestPostContainer(container) {
  if (!container) return null;

  const fullText = container.innerText || '';
  if (fullText.trim().length < 30) return null;

  const regex = getEmailRegex();
  const emailMatches = fullText.match(regex);
  const validEmails = emailMatches ? emailMatches.filter(isValidEmail) : [];
  const hrEmail = validEmails.length > 0 ? validEmails[0].toLowerCase() : null;

  const authorDetails = extractAuthorDetails(container, hrEmail);
  const title = extractJobTitle(fullText, container);
  const location = extractLocation(fullText, container);
  const salary = extractSalary(fullText);
  const requirements = extractRequirements(fullText);
  const directPostUrl = extractExactPostPermalink(container);

  const postKey = `${title.toLowerCase()}_${authorDetails.company.toLowerCase()}_${directPostUrl}`;
  if (processedPosts.has(postKey)) return null;

  const payload = {
    title: title,
    company: authorDetails.company,
    location: location,
    description: fullText.substring(0, 2000),
    requirements: requirements,
    salary: salary,
    sourceUrl: directPostUrl,
    hrName: authorDetails.name,
    hrEmail: hrEmail,
    hrTitle: authorDetails.title
  };

  return { payload, postKey, container };
}

// 13. Main Job Post Harvester Function with Parent-Only Filtering
function harvestAllVisibleJobPosts() {
  let rawElements = Array.from(document.querySelectorAll(
    '.feed-shared-update-v2, .job-card-container, .jobs-search-results-list__list-item, .jobs-details-module, div[data-urn*="activity"], article, .reusable-search__result-container, .entity-result, li.reusable-search__result-container, .search-results-container article, .job-details-jobs-unified-top-card, .jobs-unified-top-card, .jobs-details, div[data-chaperone-results], main section, .scaffold-layout__main'
  ));

  // Universal Fallback: If no standard containers match, scan page elements for hiring text or email patterns
  if (rawElements.length === 0) {
    const candidates = Array.from(document.querySelectorAll('div, section, article, li'));
    rawElements = candidates.filter(el => {
      const text = el.innerText || '';
      if (text.length < 50 || text.length > 5000) return false;
      const lower = text.toLowerCase();
      const hasEmail = getEmailRegex().test(text);
      const hasHiringKeyword = lower.includes('hiring') || lower.includes('role:') || lower.includes('position:') || lower.includes('looking for') || lower.includes('developer') || lower.includes('engineer');
      return hasEmail || hasHiringKeyword;
    });
  }

  const allContainers = Array.from(new Set(rawElements));

  // Filter out nested child nodes (only keep top-level containers)
  const containers = allContainers.filter(c => !allContainers.some(parent => parent !== c && parent.contains(c)));

  let count = 0;

  containers.forEach(container => {
    const result = parseAndHarvestPostContainer(container);
    if (result) {
      const { payload, postKey, container: postEl } = result;

      sendPayloadToBackend(payload, postKey);
      count++;

      injectInlineHarvestButton(postEl, payload, postKey);
    } else {
      const fullText = container.innerText || '';
      if (fullText.trim().length > 30) {
        const regex = getEmailRegex();
        const emailMatches = fullText.match(regex);
        const validEmails = emailMatches ? emailMatches.filter(isValidEmail) : [];
        const hrEmail = validEmails.length > 0 ? validEmails[0].toLowerCase() : null;
        const authorDetails = extractAuthorDetails(container, hrEmail);
        const title = extractJobTitle(fullText, container);
        const directPostUrl = extractExactPostPermalink(container);
        const postKey = `${title.toLowerCase()}_${authorDetails.company.toLowerCase()}_${directPostUrl}`;
        
        const payload = {
          title: title,
          company: authorDetails.company,
          location: extractLocation(fullText, container),
          description: fullText.substring(0, 2000),
          requirements: extractRequirements(fullText),
          salary: extractSalary(fullText),
          sourceUrl: directPostUrl,
          hrName: authorDetails.name,
          hrEmail: hrEmail,
          hrTitle: authorDetails.title
        };
        injectInlineHarvestButton(container, payload, postKey);
      }
    }
  });

  return count;
}

// 14. Inject Inline "⚡ Harvest Job Post" Action Button
function injectInlineHarvestButton(postContainer, payload, postKey) {
  if (!postContainer || postContainer.querySelector('.easynaukri-save-job-btn')) return;

  const actionBar = postContainer.querySelector(
    '.feed-shared-social-action-bar, .feed-shared-footer, .job-card-container__action-container, .update-components-actor'
  ) || postContainer;

  const btn = document.createElement('button');
  btn.className = 'easynaukri-save-job-btn';
  btn.style.cssText = `
    display: inline-flex !important;
    align-items: center !important;
    gap: 6px !important;
    width: auto !important;
    height: 28px !important;
    background: linear-gradient(135deg, #10b981 0%, #059669 100%) !important;
    color: #ffffff !important;
    border: none !important;
    padding: 4px 12px !important;
    margin: 6px 10px !important;
    border-radius: 14px !important;
    font-size: 11px !important;
    font-weight: 700 !important;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important;
    cursor: pointer !important;
    box-shadow: 0 2px 6px rgba(16, 185, 129, 0.4) !important;
    box-sizing: border-box !important;
    white-space: nowrap !important;
    z-index: 99;
  `;
  btn.innerHTML = `<span>⚡</span> <span>Harvest Job Post</span>`;

  btn.addEventListener('click', (e) => {
    e.preventDefault();
    e.stopPropagation();
    btn.innerHTML = `<span>✓</span> <span>Harvested!</span>`;
    btn.style.background = '#047857';
    sendPayloadToBackend(payload, postKey);
  });

  actionBar.appendChild(btn);
}

// 15. Debounced Observer & Initialization (Optimized to Eliminate CPU Lag)
let debounceHarvesterTimer = null;
function debouncedHarvestAll() {
  if (debounceHarvesterTimer) clearTimeout(debounceHarvesterTimer);
  debounceHarvesterTimer = setTimeout(() => {
    harvestAllVisibleJobPosts();
  }, 800);
}

function initHarvester() {
  if (!document.body) return;
  injectTopHarvesterBar();

  const observer = new MutationObserver(() => {
    debouncedHarvestAll();
  });

  observer.observe(document.body, { childList: true, subtree: true });

  setInterval(() => {
    debouncedHarvestAll();
  }, 5000);

  harvestAllVisibleJobPosts();
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initHarvester);
} else {
  initHarvester();
}
