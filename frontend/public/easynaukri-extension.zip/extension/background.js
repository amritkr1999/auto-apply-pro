// EasyNaukri Harvester Background Service Worker

const BACKEND_URL = 'http://localhost:8060'; // Backend API endpoint

chrome.runtime.onInstalled.addListener(() => {
  console.log('⚡ EasyNaukri Harvester Extension active.');
  chrome.alarms.create('drain_sync_queue', { periodInMinutes: 0.5 });
});

// Alarm Listener (persists across MV3 service worker sleeps)
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'drain_sync_queue') {
    processPendingQueue();
  }
});

// Storage Change Listener (wakes up worker instantly when content script adds to queue)
chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName === 'local' && changes.pending_sync_queue) {
    processPendingQueue();
  }
});

// Process pending items from chrome.storage.local queue
async function processPendingQueue() {
  try {
    const data = await chrome.storage.local.get(['pending_sync_queue']);
    const queue = data.pending_sync_queue || [];
    if (queue.length === 0) return;

    console.log(`⚡ Draining ${queue.length} pending items from storage queue...`);
    const remaining = [];

    for (const entry of queue) {
      try {
        const res = await fetch(`${BACKEND_URL}/api/v1/jobs/scraper/client-sync`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            clientNodeId: 'chrome-ext-storage-' + Math.random().toString(36).substring(7),
            sourcePortal: entry.sourcePortal || 'Storage Harvester Queue',
            items: [entry.item]
          })
        });
        if (!res.ok) {
          remaining.push(entry);
        }
      } catch (e) {
        remaining.push(entry);
      }
    }
    await chrome.storage.local.set({ pending_sync_queue: remaining });
  } catch (err) {
    console.error('Error draining pending queue:', err);
  }
}

// Drain queue on startup
processPendingQueue();

// Listen for sync messages from content scripts (LinkedIn, Naukri, Indeed)
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'DRAIN_QUEUE_NOW') {
    processPendingQueue().then(() => sendResponse({ success: true }));
    return true;
  }

  if (message.type === 'SYNC_SCRAPED_PAYLOAD') {
    (async () => {
      try {
        const item = message.item;
        const res = await fetch(`${BACKEND_URL}/api/v1/jobs/scraper/client-sync`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            clientNodeId: 'chrome-ext-node-' + Math.random().toString(36).substring(7),
            sourcePortal: message.sourcePortal || 'Background Harvester Node',
            items: [item]
          })
        });

        if (res.ok) {
          const syncData = await res.json();
          console.log('Background sync successful:', syncData);
          sendResponse({ success: true, data: syncData });
        } else {
          // Push to storage queue on non-200 HTTP status
          chrome.storage.local.get(['pending_sync_queue'], (data) => {
            const queue = data.pending_sync_queue || [];
            queue.push({ item: message.item, sourcePortal: message.sourcePortal });
            chrome.storage.local.set({ pending_sync_queue: queue });
          });
          sendResponse({ success: false, error: 'HTTP status ' + res.status });
        }
      } catch (err) {
        console.error('Failed to sync item from background script, pushing to queue:', err);
        chrome.storage.local.get(['pending_sync_queue'], (data) => {
          const queue = data.pending_sync_queue || [];
          queue.push({ item: message.item, sourcePortal: message.sourcePortal });
          chrome.storage.local.set({ pending_sync_queue: queue });
        });
        sendResponse({ success: false, error: err.message });
      }
    })();
    return true; // Keep response channel open for async response
  }
});
